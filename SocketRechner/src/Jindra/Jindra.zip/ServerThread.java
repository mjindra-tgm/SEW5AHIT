package Jindra;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * Eine Server Thread Klasse die f�r die Kommunikation mit nur jeweils einem Client
 * @author Michael Jindra
 * @version 16-02-2018
 */
public class ServerThread extends Thread{
	Socket client = null;
	BufferedReader in = null;
	PrintWriter out = null;
	String clientIP = null;
	
	/**
	 * Konstruktor
	 * @param client Socket vom Main Server �bergeben
	 * @since 16-02-2018
	 */
	public ServerThread(Socket client) {
		this.client = client;
		this.clientIP = client.getInetAddress().toString();
		
		try {
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		try {
			out = new PrintWriter(client.getOutputStream(), true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		out.println("Hello "+clientIP+" send me your calculations!");
	}

	/**
	 * Die run antwortet auf die Commands des Clients
	 * @since 16-02-2018
	 */
	@Override
	public void run() {
		super.run();
		String message=null;
		while(true) {
			try {
				message=in.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			String[] args = message.split(" ");
			switch(args[0]) {
			case "!exit":
				out.println("Bye!");
				try {
					client.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				return;
				
			case "!add":
				if(Server.getcredits(clientIP)==0) {
					out.println("Sorry, you don't have enough Credits. Buy some with \"!buy <how many> \"");
				}else {
					Server.subcredits(clientIP);
					out.println(Integer.parseInt(args[1])+Integer.parseInt(args[2])+" Credits: "+Server.getcredits(clientIP));
					Server.incActions(clientIP);
				}
				break;
				
			case "!sub":
				if(Server.getcredits(clientIP)==0) {
					out.println("Sorry, you don't have enough Credits. Buy some with \"!buy <nr> \"");
				}else {
					Server.subcredits(clientIP);
					out.println(Integer.parseInt(args[1])-Integer.parseInt(args[2])+" Credits: "+Server.getcredits(clientIP));
				}
				break;
				
			case "!buy":
				Server.addcredits(clientIP, Integer.parseInt(args[1]));
				out.println("Credits: "+Server.getcredits(clientIP));
				break;
				
			case "!help":
				out.println("!add <nr1> <nr2>\n!sub <nr1> <nr2>\n!exit\n!buy <nr>");
				break;
				
			default:
				out.println("No valid command. Try to type !help");
				break;
			}
			
		}
	}
}
